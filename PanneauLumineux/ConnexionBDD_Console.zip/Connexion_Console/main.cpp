#include <QCoreApplication>
#include <QtSql>
#include <QSqlDatabase>
#include <iostream>
#include "/home/snir/Documents/PROJET/libs/sqlrequest.h"

int nb;

int main(int argc, char *argv[])
{
    QCoreApplication a(argc, argv);

    QSqlDatabase db = QSqlDatabase::addDatabase("QMYSQL");
    db.setHostName("localhost");
    db.setUserName("portail");
    db.setPassword("portail");
    db.setDatabaseName("Portail");
    if(db.open())

    {
        qDebug ("Base de donnée connecté");

        QSqlQuery requete ;
        requete.exec ("SELECT * FROM Parking");

                            while (requete.next ()){
                                nb = requete.value(0).toInt();
              qDebug () << requete.value(0).toInt();
           }

    }

    else

    {
        qDebug ("Base de donnée non-connecté");
    }

    db.close();

    return a.exec();

}
